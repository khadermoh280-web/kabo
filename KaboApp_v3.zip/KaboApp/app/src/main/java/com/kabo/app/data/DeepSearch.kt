package com.kabo.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Source(val title: String, val url: String, val text: String)
data class DeepResult(val answer: String, val sources: List<Source>)
data class AiCfg(val base: String, val model: String, val key: String)

/**
 * بحث عميق: نموذج مفتوح يولّد استعلامات بحث → بحث بالنت (DuckDuckGo + أخبار) →
 * تحميل الصفحات وقراءتها → نموذج مفتوح يلخّص ويجاوب مع أرقام المصادر.
 * النموذج عبر أي خدمة متوافقة مع OpenAI (Hugging Face، Ollama على جهازك، vLLM، OpenRouter...).
 */
object DeepSearch {
    private val client = OkHttpClient.Builder().callTimeout(60, TimeUnit.SECONDS).build()
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"

    fun cfg(ctx: Context): AiCfg {
        val p = ctx.getSharedPreferences("kabo_ai", Context.MODE_PRIVATE)
        return AiCfg(
            p.getString("base", "https://router.huggingface.co/v1")!!,
            p.getString("model", "Qwen/Qwen2.5-72B-Instruct")!!,
            p.getString("key", "")!!
        )
    }

    fun save(ctx: Context, c: AiCfg) {
        ctx.getSharedPreferences("kabo_ai", Context.MODE_PRIVATE).edit()
            .putString("base", c.base.trim()).putString("model", c.model.trim()).putString("key", c.key.trim()).apply()
    }

    private fun llm(c: AiCfg, system: String, user: String, maxTokens: Int = 1600): String {
        val body = JSONObject().put("model", c.model).put("temperature", 0.2).put("max_tokens", maxTokens)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)))
        val req = Request.Builder().url(c.base.trimEnd('/') + "/chat/completions")
            .apply { if (c.key.isNotBlank()) header("Authorization", "Bearer ${c.key}") }
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            require(r.isSuccessful) { "خطأ من خدمة الذكاء (${r.code}): ${t.take(160)}" }
            return JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
    }

    private fun ddg(q: String): List<Pair<String, String>> {
        val html = try {
            client.newCall(Request.Builder().url("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8")).header("User-Agent", UA).build())
                .execute().use { it.body?.string() }
        } catch (e: Exception) { null } ?: return emptyList()
        val re = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        return re.findAll(html).mapNotNull { m ->
            var u = m.groupValues[1].replace("&amp;", "&")
            Regex("""uddg=([^&]+)""").find(u)?.let { u = URLDecoder.decode(it.groupValues[1], "UTF-8") }
            if (!u.startsWith("http")) return@mapNotNull null
            u to clean(m.groupValues[2])
        }.toList()
    }

    private fun clean(h: String): String = h
        .replace(Regex("(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace(Regex("\\s+"), " ").trim()

    private fun page(url: String): String? = try {
        client.newCall(Request.Builder().url(url).header("User-Agent", UA).build()).execute().use { r ->
            val ct = r.header("Content-Type").orEmpty()
            if (!r.isSuccessful || !ct.contains("html")) null else clean(r.body!!.source().readUtf8().take(400_000)).take(3500)
        }
    } catch (e: Exception) { null }

    suspend fun run(ctx: Context, question: String, status: (String) -> Unit): DeepResult = withContext(Dispatchers.IO) {
        val c = cfg(ctx)
        status("عم أحضّر استعلامات البحث...")
        val queries = try {
            llm(c, "أنت خبير بحث. اكتب 3 استعلامات بحث قصيرة ومختلفة (واحد عربي وواحد إنجليزي على الأقل) تغطي السؤال. سطر لكل استعلام بدون ترقيم أو شرح.",
                question, 120).lines().map { it.trim().trim('-', '*', '"') }.filter { it.isNotBlank() }.take(3)
        } catch (e: Exception) { emptyList() }.ifEmpty { listOf(question) }

        status("عم أبحث بالنت (${queries.size + 1} عمليات بحث)...")
        val found = coroutineScope { queries.map { async { ddg(it) } }.awaitAll() }.flatten().distinctBy { it.first }.take(8)
        val news = NewsFeed.fetch(question, 6)

        status("عم أقرأ ${found.size} صفحة...")
        val pages = coroutineScope { found.map { (u, t) -> async { page(u)?.let { Source(t, u, it) } } }.awaitAll() }.filterNotNull().toMutableList()
        if (news.isNotEmpty()) pages += Source("أخبار حديثة", news.first().link,
            news.joinToString("\n") { "- ${it.title} (${it.source}، ${it.date})" })
        require(pages.isNotEmpty()) { "ما لقيت نتائج. تأكد من النت وجرب صياغة ثانية." }

        status("الذكاء الاصطناعي عم يحلل المصادر ويكتب الجواب...")
        val ctxText = pages.mapIndexed { i, s -> "[${i + 1}] ${s.title} — ${s.url}\n${s.text}" }.joinToString("\n\n")
        val answer = llm(c,
            "أنت باحث دقيق. أجب بالعربية فقط اعتمادًا على المصادر المرفقة. ضع رقم المصدر [n] بعد كل معلومة. " +
            "إذا تعارضت المصادر أو نقصت المعلومات قل ذلك بوضوح ولا تخمّن. لا تذكر معلومات خاصة عن أفراد عاديين (عنوان، هاتف، تفاصيل عائلية). " +
            "رتّب الجواب بعناوين قصيرة ونقاط.",
            "السؤال: $question\n\nالمصادر:\n$ctxText", 1800)
        DeepResult(answer, pages)
    }
}
