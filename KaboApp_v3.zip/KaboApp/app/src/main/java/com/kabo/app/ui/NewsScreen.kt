package com.kabo.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.NewsFeed
import com.kabo.app.data.NewsItem
import com.kabo.app.data.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun NewsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var topics by remember { mutableStateOf(store.topics()) }
    var selected by remember { mutableStateOf(topics.firstOrNull()) }
    var input by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(selected, refreshKey) {
        val t = selected ?: return@LaunchedEffect
        loading = true
        items = withContext(Dispatchers.IO) { NewsFeed.fetch(t) }
        loading = false
    }

    ScreenFrame("الأخبار", onBack) {
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input = it }, label = { Text("موضوع (اختراقات، حرب، ذكاء اصطناعي...)") },
                    singleLine = true, modifier = Modifier.weight(1f))
                GradientButton("إضافة") {
                    val t = input.trim()
                    if (t.isNotEmpty() && t !in topics) { topics = topics + t; store.saveTopics(topics); selected = t }
                    input = ""
                }
            }
            if (topics.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(topics) { t ->
                        Box(
                            Modifier.background(if (t == selected) C.violet else C.glass, RoundedCornerShape(50))
                                .clickableNoRipple { if (t == selected) refreshKey++ else selected = t }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) { Text(t, color = C.text) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("اضغط على الموضوع المحدد مرة ثانية لتحديث الأخبار", color = C.dim, fontSize = 11.sp)
                TextButton({ selected?.let { s -> topics = topics - s; store.saveTopics(topics); selected = topics.firstOrNull(); items = emptyList() } }) {
                    Text("حذف الموضوع المحدد", color = C.red)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (topics.isEmpty()) Text("أضف موضوع وبجيبلك آخر الأخبار عنه كل ما تفتح الصفحة.", color = C.dim)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(items) { n ->
                Glass(Modifier.fillMaxWidth().clickableNoRipple {
                    Gate.suppress = true
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)))
                }) {
                    Text(n.title, color = C.text, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("${n.source}  ·  ${n.date}", color = C.dim, fontSize = 12.sp)
                }
            }
        }
    }
}
