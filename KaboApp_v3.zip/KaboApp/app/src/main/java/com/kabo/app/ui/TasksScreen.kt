package com.kabo.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kabo.app.data.Store
import com.kabo.app.data.VoiceTasks
import com.kabo.app.reminders.Reminders
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TasksScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tasks by remember { mutableStateOf(store.tasks().sortedWith(compareBy({ it.done }, { -it.priority }, { it.due }))) }
    var recording by remember { mutableStateOf(false) }
    var level by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("اضغط وسجل كل شي بدك تتذكره") }
    val fmt = remember { SimpleDateFormat("EEE dd/MM  HH:mm", Locale("ar")) }
    var recognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }

    fun refresh() { tasks = store.tasks().sortedWith(compareBy({ it.done }, { -it.priority }, { it.due })) }

    fun start() {
        var peak = 0f; var sum = 0f; var n = 0
        val t0 = System.currentTimeMillis()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onRmsChanged(rmsdB: Float) {
                val v = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                level = v; sum += v; n++; peak = maxOf(peak, v)
            }
            override fun onResults(results: Bundle?) {
                recording = false; level = 0f
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) { status = "ما سمعت شي، جرب مرة ثانية"; return }
                val secs = ((System.currentTimeMillis() - t0) / 1000f).coerceAtLeast(1f)
                val wps = text.split(" ").size / secs
                val found = VoiceTasks.parse(text, if (n > 0) sum / n else 0f, wps)
                found.forEach { store.addTask(it); Reminders.schedule(ctx, it.id, it.text, it.due, it.priority) }
                status = "ضفت ${found.size} مهمة ورتبتها حسب الأولوية"
                refresh()
            }
            override fun onError(error: Int) { recording = false; level = 0f; status = "ما التقطت الصوت، جرب مرة ثانية" }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        recognizer = r
        recording = true; status = "عم بسمعك... احكي كل مهامك"
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-PS")
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L)
        )
    }

    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) start() else status = "لازم تسمح بالميكروفون" }

    DisposableEffect(Unit) { onDispose { recognizer?.destroy() } }
    LaunchedEffect(Unit) { askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }

    val pulse by rememberInfiniteTransition(label = "m").animateFloat(
        1f, 1.18f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "ps"
    )

    ScreenFrame("مهامي الصوتية", onBack) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(92.dp).scale(if (recording) pulse + level * .25f else 1f)
                        .background(Brush.linearGradient(listOf(C.violet, C.pink)), CircleShape)
                        .clickableNoRipple {
                            if (recording) recognizer?.stopListening()
                            else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) start()
                            else askMic.launch(Manifest.permission.RECORD_AUDIO)
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(if (recording) Icons.Default.Stop else Icons.Default.Mic, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(42.dp)) }
                Spacer(Modifier.height(12.dp))
                Text(status, color = C.dim, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(tasks, key = { it.id }) { t ->
                val pc = when (t.priority) { 3 -> C.red; 2 -> C.amber; else -> C.cyan }
                Glass(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(t.done, { store.setDone(t.id, it); refresh() })
                        Column(Modifier.weight(1f)) {
                            Text(t.text, color = if (t.done) C.dim else C.text)
                            Text(fmt.format(Date(t.due)), color = C.dim, fontSize = 12.sp)
                        }
                        Text(when (t.priority) { 3 -> "عاجل"; 2 -> "مهم"; else -> "عادي" }, color = pc, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
