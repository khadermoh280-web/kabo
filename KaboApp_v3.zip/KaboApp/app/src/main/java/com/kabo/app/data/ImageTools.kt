package com.kabo.app.data

import android.content.Context
import android.graphics.Bitmap
import android.content.ContentValues
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.nio.FloatBuffer
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.tasks.await
import com.googlecode.tesseract.android.TessBaseAPI
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import kotlin.math.max
import kotlin.math.min

object ImageTools {

    // ---------- استخراج النص (عربي + إنجليزي) ----------

    /** يحمل بيانات اللغة مرة واحدة (حوالي 10MB) ثم يشتغل بدون نت. */
    private fun ensureData(ctx: Context): File {
        val root = File(ctx.filesDir, "tess"); val tessdata = File(root, "tessdata").apply { mkdirs() }
        listOf("ara", "eng").forEach { lang ->
            val f = File(tessdata, "$lang.traineddata")
            if (!f.exists() || f.length() < 1000) {
                val url = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata"
                OkHttpClient().newCall(Request.Builder().url(url).build()).execute().use { r ->
                    require(r.isSuccessful) { "فشل تحميل بيانات اللغة" }
                    f.writeBytes(r.body!!.bytes())
                }
            }
        }
        return root
    }

    fun ocr(ctx: Context, bmp: Bitmap): String {
        val api = TessBaseAPI()
        try {
            require(api.init(ensureData(ctx).absolutePath, "ara+eng")) { "تعذر تشغيل المحرك" }
            api.setImage(bmp.copy(Bitmap.Config.ARGB_8888, false))
            return api.utF8Text.orEmpty().trim()
        } finally { api.recycle() }
    }

    // ---------- تحسين الصور القديمة ----------

    /**
     * تحسين كلاسيكي (مش ذكاء اصطناعي توليدي): تكبير x2، تقليل ضجيج خفيف،
     * شحذ، تمديد التباين، وزيادة تشبع الألوان. بيحسن الوضوح لكن ما بيخترع تفاصيل مفقودة.
     */
    fun enhance(src: Bitmap): Bitmap {
        val scale = if (max(src.width, src.height) < 1600) 2f else 1f
        val big = Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        val w = big.width; val h = big.height
        val px = IntArray(w * h).also { big.getPixels(it, 0, w, 0, 0, w, h) }

        val soft = boxBlur(px, w, h, 1)           // تنعيم خفيف للضجيج
        val blur = boxBlur(px, w, h, 3)           // للشحذ (unsharp mask)

        // تمديد التباين من المدرج التكراري (قص 1% من الأطراف)
        val hist = IntArray(256)
        for (c in soft) hist[(0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)).toInt()]++
        val cut = (w * h * 0.01).toInt()
        var lo = 0; var acc = 0
        while (lo < 255 && acc + hist[lo] < cut) { acc += hist[lo]; lo++ }
        var hi = 255; acc = 0
        while (hi > 0 && acc + hist[hi] < cut) { acc += hist[hi]; hi-- }
        val range = max(1, hi - lo).toFloat()

        val out = IntArray(w * h)
        for (i in out.indices) {
            val s = soft[i]; val b = blur[i]
            fun ch(sv: Int, bv: Int): Int {
                val sharp = sv + 1.2f * (sv - bv)
                return ((sharp - lo) / range * 255f).toInt().coerceIn(0, 255)
            }
            var r = ch(Color.red(s), Color.red(b)); var g = ch(Color.green(s), Color.green(b)); var bl = ch(Color.blue(s), Color.blue(b))
            val gray = (r + g + bl) / 3f
            r = (gray + (r - gray) * 1.2f).toInt().coerceIn(0, 255)
            g = (gray + (g - gray) * 1.2f).toInt().coerceIn(0, 255)
            bl = (gray + (bl - gray) * 1.2f).toInt().coerceIn(0, 255)
            out[i] = Color.rgb(r, g, bl)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- أدوات إضافية ----------

    /** إزالة الخلفية بنموذج ذكاء اصطناعي على الجهاز (ML Kit). الناتج PNG شفاف. */
    suspend fun removeBackground(bmp: Bitmap): Bitmap {
        val seg = SubjectSegmentation.getClient(SubjectSegmenterOptions.Builder().enableForegroundBitmap().build())
        try {
            val r = seg.process(InputImage.fromBitmap(bmp, 0)).await()
            return r.foregroundBitmap ?: error("ما قدرت أفصل العنصر عن الخلفية")
        } finally { seg.close() }
    }

    fun rotate(b: Bitmap, deg: Float): Bitmap =
        Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)

    /** تصغير للحد الأقصى للضلع الأطول (لضغط الحجم). */
    fun shrink(b: Bitmap, maxSide: Int): Bitmap {
        val m = max(b.width, b.height)
        if (m <= maxSide) return b
        val f = maxSide.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt(), (b.height * f).toInt(), true)
    }

    /** فلتر "مستند": أبيض وأسود مع تباين عالي. */
    fun docFilter(b: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(0f) }
        val k = 1.7f; val t = (-0.5f * k + 0.5f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(k,0f,0f,0f,t, 0f,k,0f,0f,t, 0f,0f,k,0f,t, 0f,0f,0f,1f,0f)))
        Canvas(out).drawBitmap(b, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    /** يجمع عدة صور بملف PDF واحد (صفحة لكل صورة) ويحفظه بمجلد Download/Kabo. */
    fun imagesToPdf(ctx: Context, uris: List<Uri>): String {
        require(Build.VERSION.SDK_INT >= 29) { "الميزة بتحتاج أندرويد 10 أو أحدث" }
        val pdf = PdfDocument()
        uris.forEachIndexed { i, u ->
            val raw = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } ?: return@forEachIndexed
            val b = shrink(raw, 1800)
            val pw = 595; val ph = 842
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
            val f = min(pw.toFloat() / b.width, ph.toFloat() / b.height)
            val dw = b.width * f; val dh = b.height * f
            page.canvas.drawColor(Color.WHITE)
            page.canvas.drawBitmap(b, null, android.graphics.RectF((pw - dw) / 2, (ph - dh) / 2, (pw + dw) / 2, (ph + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
            pdf.finishPage(page)
        }
        require(pdf.pages.isNotEmpty()) { "ما قدرت أقرأ الصور" }
        val name = "kabo_${System.currentTimeMillis()}.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/Kabo")
        }
        val out = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("تعذر إنشاء الملف")
        ctx.contentResolver.openOutputStream(out)?.use { pdf.writeTo(it) }
        pdf.close()
        return "Download/Kabo/$name"
    }

    // ---------- تكبير وترميم بالذكاء الاصطناعي (Real-ESRGAN، مفتوح المصدر) ----------

    private const val SR_URL = "https://huggingface.co/qualcomm/Real-ESRGAN-General-x4v3/resolve/main/Real-ESRGAN-General-x4v3.onnx"

    private fun srModel(ctx: Context, onStatus: (String) -> Unit): File {
        val f = File(ctx.filesDir, "realesrgan_x4v3.onnx")
        if (!f.exists() || f.length() < 1_000_000) {
            onStatus("عم أنزّل نموذج الذكاء الاصطناعي (حوالي 5MB، مرة وحدة فقط)...")
            OkHttpClient().newCall(Request.Builder().url(SR_URL).build()).execute().use { r ->
                require(r.isSuccessful) { "فشل تنزيل النموذج (${r.code})" }
                val tmp = File(f.path + ".tmp"); tmp.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
                tmp.renameTo(f)
            }
        }
        return f
    }

    /**
     * يكبّر الصورة 4 أضعاف ويرمّم التفاصيل والضجيج وتأثير الضغط (JPEG) بنموذج Real-ESRGAN.
     * يشتغل على الجهاز بدون نت بعد أول تنزيل. المعالجة على مربعات مع تداخل عشان الذاكرة.
     */
    fun aiUpscale(ctx: Context, src: Bitmap, onStatus: (String) -> Unit): Bitmap {
        val model = srModel(ctx, onStatus)
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 6)) }
        env.createSession(model.absolutePath, opts).use { session ->
            val inName = session.inputNames.first()
            val shape = (session.inputInfo[inName]!!.info as TensorInfo).shape
            val tH = if (shape.size == 4 && shape[2] > 0) shape[2].toInt() else 128
            val tW = if (shape.size == 4 && shape[3] > 0) shape[3].toInt() else 128
            val pad = 8
            val stepH = tH - 2 * pad; val stepW = tW - 2 * pad
            val bmp = shrink(src, 896)                       // الناتج بحدود 3584 بكسل
            val w = bmp.width; val h = bmp.height
            val px = IntArray(w * h).also { bmp.getPixels(it, 0, w, 0, 0, w, h) }
            val ow = w * 4
            val out = IntArray(ow * h * 4)
            val total = ((h + stepH - 1) / stepH) * ((w + stepW - 1) / stepW)
            var done = 0
            var y = 0
            while (y < h) {
                var x = 0
                while (x < w) {
                    val buf = FloatBuffer.allocate(3 * tH * tW)
                    for (c in 0..2) for (ty in 0 until tH) {
                        val sy = (y - pad + ty).coerceIn(0, h - 1)
                        for (tx in 0 until tW) {
                            val p = px[sy * w + (x - pad + tx).coerceIn(0, w - 1)]
                            val v = when (c) { 0 -> Color.red(p); 1 -> Color.green(p); else -> Color.blue(p) }
                            buf.put(v / 255f)
                        }
                    }
                    buf.rewind()
                    OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, tH.toLong(), tW.toLong())).use { t ->
                        session.run(mapOf(inName to t)).use { res ->
                            @Suppress("UNCHECKED_CAST")
                            val o = (res[0].value as Array<Array<Array<FloatArray>>>)[0]
                            for (ty in pad until tH - pad) {
                                val sy = y - pad + ty
                                if (sy < 0 || sy >= h) continue
                                for (tx in pad until tW - pad) {
                                    val sx = x - pad + tx
                                    if (sx < 0 || sx >= w) continue
                                    for (dy in 0..3) for (dx in 0..3) {
                                        val oy = ty * 4 + dy; val ox = tx * 4 + dx
                                        out[(sy * 4 + dy) * ow + sx * 4 + dx] = Color.rgb(
                                            (o[0][oy][ox] * 255f).toInt().coerceIn(0, 255),
                                            (o[1][oy][ox] * 255f).toInt().coerceIn(0, 255),
                                            (o[2][oy][ox] * 255f).toInt().coerceIn(0, 255))
                                    }
                                }
                            }
                        }
                    }
                    done++; onStatus("ترميم الصورة بالذكاء الاصطناعي... ${done * 100 / total}%")
                    x += stepW
                }
                y += stepH
            }
            return Bitmap.createBitmap(out, ow, h * 4, Bitmap.Config.ARGB_8888)
        }
    }

    private fun boxBlur(src: IntArray, w: Int, h: Int, r: Int): IntArray {
        fun pass(inp: IntArray, horizontal: Boolean): IntArray {
            val out = IntArray(inp.size)
            for (y in 0 until h) for (x in 0 until w) {
                var sr = 0; var sg = 0; var sb = 0; var n = 0
                for (k in -r..r) {
                    val xx = if (horizontal) min(w - 1, max(0, x + k)) else x
                    val yy = if (horizontal) y else min(h - 1, max(0, y + k))
                    val c = inp[yy * w + xx]
                    sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c); n++
                }
                out[y * w + x] = Color.rgb(sr / n, sg / n, sb / n)
            }
            return out
        }
        return pass(pass(src, true), false)
    }
}
