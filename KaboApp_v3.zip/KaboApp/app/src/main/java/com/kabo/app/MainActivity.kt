package com.kabo.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.fragment.app.FragmentActivity
import com.kabo.app.ui.*

enum class Screen { HOME, MONEY, TASKS, VAULT, PHOTO, NEWS, PEOPLE, DEEP, ASSISTANT }

/** الشاشات اللي بتفتح منتقي صور/ملفات بتضبط suppress حتى ما ينقفل التطبيق وهو راجع منها. */
object Gate { var suppress = false }

class MainActivity : FragmentActivity() {
    private val unlockedState = mutableStateOf(false)

    override fun onResume() { super.onResume(); Gate.suppress = false }

    override fun onStop() {
        super.onStop()
        if (!Gate.suppress && !isChangingConfigurations) unlockedState.value = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // يمنع لقطات الشاشة وصورة التطبيق في قائمة التطبيقات الأخيرة
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        setContent {
            KaboTheme {
                var unlocked by unlockedState
                var screen by remember { mutableStateOf(Screen.HOME) }
                BackHandler(enabled = unlocked && screen != Screen.HOME) { screen = Screen.HOME }

                if (!unlocked) {
                    LockScreen(this@MainActivity) { unlocked = true }
                } else {
                    AuroraBackground {
                        AnimatedContent(
                            screen,
                            transitionSpec = { (fadeIn() + scaleIn(initialScale = .96f)) togetherWith fadeOut() },
                            label = "nav"
                        ) { s ->
                            when (s) {
                                Screen.HOME -> HomeScreen { screen = it }
                                Screen.MONEY -> MoneyScreen { screen = Screen.HOME }
                                Screen.TASKS -> TasksScreen { screen = Screen.HOME }
                                Screen.VAULT -> VaultScreen { screen = Screen.HOME }
                                Screen.PHOTO -> PhotoScreen { screen = Screen.HOME }
                                Screen.NEWS -> NewsScreen { screen = Screen.HOME }
                                Screen.PEOPLE -> PeopleScreen { screen = Screen.HOME }
                                Screen.DEEP -> DeepScreen { screen = Screen.HOME }
                                Screen.ASSISTANT -> AssistantScreen { screen = Screen.HOME }
                            }
                        }
                    }
                }
            }
        }
    }
}
