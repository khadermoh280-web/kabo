package com.kabo.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.data.Store
import com.kabo.app.data.Txn
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MoneyScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var list by remember { mutableStateOf(store.txns()) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }

    fun add(income: Boolean) {
        val a = amount.replace(',', '.').toDoubleOrNull() ?: return
        store.addTxn(Txn(System.currentTimeMillis(), a, income, note.ifBlank { if (income) "دخل" else "صرف" }, System.currentTimeMillis()))
        amount = ""; note = ""; list = store.txns()
    }

    val balance = list.filter { it.income }.sumOf { it.amount } - list.filter { !it.income }.sumOf { it.amount }
    val monthFmt = remember { SimpleDateFormat("yyyy-MM", Locale.ENGLISH) }
    val dayFmt = remember { SimpleDateFormat("dd/MM  HH:mm", Locale.ENGLISH) }

    ScreenFrame("المصاريف", onBack) {
        Glass(Modifier.fillMaxWidth()) {
            Text("الرصيد الكلي", color = C.dim)
            Text("%,.2f".format(balance), color = if (balance >= 0) C.green else C.red, fontSize = 36.sp)
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") }, singleLine = true, modifier = Modifier.weight(1.4f))
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f).background(C.green.copy(alpha = .25f), RoundedCornerShape(16.dp))
                    .clickableNoRipple { add(true) }.padding(14.dp), contentAlignment = Alignment.Center) { Text("+ دخل", color = C.green) }
                Box(Modifier.weight(1f).background(C.red.copy(alpha = .25f), RoundedCornerShape(16.dp))
                    .clickableNoRipple { add(false) }.padding(14.dp), contentAlignment = Alignment.Center) { Text("− صرف", color = C.red) }
            }
        }
        Spacer(Modifier.height(10.dp))
        TabRow(tab, containerColor = androidx.compose.ui.graphics.Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text("الجرد") })
            Tab(tab == 1, { tab = 1 }, text = { Text("التقرير الشهري") })
        }
        Spacer(Modifier.height(8.dp))

        if (tab == 0) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(list, key = { it.id }) { t ->
                    Glass(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(t.note, color = C.text)
                                Text(dayFmt.format(Date(t.time)), color = C.dim, fontSize = 12.sp)
                            }
                            Text((if (t.income) "+" else "−") + "%,.2f".format(t.amount), color = if (t.income) C.green else C.red)
                            IconButton(onClick = { store.deleteTxn(t.id); list = store.txns() }) {
                                Icon(Icons.Default.Delete, "حذف", tint = C.dim)
                            }
                        }
                    }
                }
            }
        } else {
            val byMonth = list.groupBy { monthFmt.format(Date(it.time)) }.toSortedMap(reverseOrder())
            val maxV = byMonth.values.maxOfOrNull { m -> maxOf(m.filter { it.income }.sumOf { it.amount }, m.filter { !it.income }.sumOf { it.amount }) } ?: 1.0
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(byMonth.entries.toList()) { (m, tx) ->
                    val inc = tx.filter { it.income }.sumOf { it.amount }
                    val out = tx.filter { !it.income }.sumOf { it.amount }
                    Glass(Modifier.fillMaxWidth()) {
                        Text(m, color = C.text, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        Bar("دخل", inc, maxV, C.green)
                        Spacer(Modifier.height(6.dp))
                        Bar("صرف", out, maxV, C.red)
                        Spacer(Modifier.height(8.dp))
                        Text("الصافي  %,.2f".format(inc - out), color = if (inc >= out) C.green else C.red)
                    }
                }
            }
        }
    }
}

@Composable
private fun Bar(label: String, value: Double, max: Double, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = C.dim, modifier = Modifier.width(46.dp), fontSize = 13.sp)
        Box(Modifier.weight(1f).height(10.dp).background(C.glass, RoundedCornerShape(5.dp))) {
            Box(Modifier.fillMaxWidth((value / max).toFloat().coerceIn(0.02f, 1f)).fillMaxHeight().background(color, RoundedCornerShape(5.dp)))
        }
        Text("  %,.0f".format(value), color = color, fontSize = 13.sp)
    }
}
