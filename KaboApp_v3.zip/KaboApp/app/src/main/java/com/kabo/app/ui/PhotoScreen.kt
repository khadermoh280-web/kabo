package com.kabo.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.ImageTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

@Composable
fun PhotoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    var asPng by remember { mutableStateOf(false) }
    var quality by remember { mutableIntStateOf(95) }

    val multi = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { us: List<Uri> ->
        if (us.isEmpty()) return@rememberLauncherForActivityResult
        busy = "عم أجمّع ${us.size} صورة بملف PDF..."
        scope.launch {
            try { msg = "انحفظ: " + withContext(Dispatchers.IO) { ImageTools.imagesToPdf(ctx, us) } }
            catch (e: Throwable) { msg = "فشل: ${e.message}" }
            busy = null
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        u ?: return@rememberLauncherForActivityResult
        src = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
        result = null; text = ""; msg = ""
    }

    ScreenFrame("أدوات الصور", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            GradientButton("اختر صورة", Modifier.fillMaxWidth()) { Gate.suppress = true; picker.launch("image/*") }
            Spacer(Modifier.height(8.dp))
            GradientButton("صور متعددة ← PDF", Modifier.fillMaxWidth()) { Gate.suppress = true; multi.launch("image/*") }
            Spacer(Modifier.height(12.dp))

            src?.let { b ->
                Image(b.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GradientButton("نسخ النص", Modifier.weight(1f)) {
                        busy = "عم أقرأ النص (أول مرة بينزل ملف اللغة)..."
                        scope.launch {
                            try { text = withContext(Dispatchers.IO) { ImageTools.ocr(ctx, b) }; msg = if (text.isBlank()) "ما لقيت نص" else "" }
                            catch (e: Exception) { msg = "فشل: ${e.message}" }
                            busy = null
                        }
                    }
                    GradientButton("تحسين سريع", Modifier.weight(1f)) {
                        busy = "عم أحسّن الصورة..."
                        scope.launch {
                            try { result = withContext(Dispatchers.Default) { ImageTools.enhance(b) }; asPng = false; quality = 95 }
                            catch (e: Throwable) { msg = "فشل التحسين: ${e.message}" }
                            busy = null
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                GradientButton("ترميم بالذكاء الاصطناعي (جودة عالية)", Modifier.fillMaxWidth()) {
                    busy = "عم أجهّز النموذج..."
                    scope.launch {
                        try { result = withContext(Dispatchers.Default) { ImageTools.aiUpscale(ctx, b) { busy = it } }; asPng = false; quality = 95 }
                        catch (e: Throwable) { msg = "فشل الترميم: ${e.message}" }
                        busy = null
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GradientButton("إزالة الخلفية", Modifier.weight(1f)) {
                        busy = "عم أفصل العنصر (أول مرة ممكن ينزل النموذج)..."
                        scope.launch {
                            try { result = ImageTools.removeBackground(b); asPng = true; quality = 100 }
                            catch (e: Throwable) { msg = "فشل: ${e.message}" }
                            busy = null
                        }
                    }
                    GradientButton("ضغط الحجم", Modifier.weight(1f)) {
                        scope.launch { result = withContext(Dispatchers.Default) { ImageTools.shrink(b, 1600) }; asPng = false; quality = 70 }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GradientButton("تدوير", Modifier.weight(1f)) {
                        scope.launch { result = withContext(Dispatchers.Default) { ImageTools.rotate(result ?: b, 90f) } }
                    }
                    GradientButton("فلتر مستند", Modifier.weight(1f)) {
                        scope.launch { result = withContext(Dispatchers.Default) { ImageTools.docFilter(b) }; asPng = false; quality = 90 }
                    }
                }
            }

            busy?.let { Spacer(Modifier.height(12.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, color = C.dim, fontSize = 13.sp) }
            if (msg.isNotBlank()) Text(msg, color = C.amber, modifier = Modifier.padding(top = 8.dp))

            if (text.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                Glass(Modifier.fillMaxWidth()) {
                    OutlinedTextField(text, { text = it }, label = { Text("النص المستخرج (تقدر تعدّل)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    GradientButton("نسخ للحافظة", Modifier.fillMaxWidth()) {
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("kabo", text))
                        msg = "تم النسخ"
                    }
                }
            }

            result?.let { r ->
                Spacer(Modifier.height(14.dp))
                Text("النتيجة", color = C.text)
                Image(r.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 320.dp), contentScale = ContentScale.Fit)
                Spacer(Modifier.height(10.dp))
                GradientButton("احفظ بالمعرض", Modifier.fillMaxWidth()) {
                    val bytes = ByteArrayOutputStream().also { r.compress(if (asPng) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
                    val values = android.content.ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "kabo_${System.currentTimeMillis()}" + (if (asPng) ".png" else ".jpg"))
                        put(MediaStore.Images.Media.MIME_TYPE, if (asPng) "image/png" else "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Kabo")
                    }
                    ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                        ?.let { u -> ctx.contentResolver.openOutputStream(u)?.use { it.write(bytes) }; msg = "انحفظت بمجلد Pictures/Kabo" }
                }
            }
        }
    }
}
