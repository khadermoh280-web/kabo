package com.kabo.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kabo.app.Gate
import com.kabo.app.data.PeopleSearch
import com.kabo.app.data.Person
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PeopleScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<List<Person>?>(null) }
    var loading by remember { mutableStateOf(false) }

    fun open(url: String) { Gate.suppress = true; ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun run() {
        if (q.isBlank()) return
        loading = true
        scope.launch { res = withContext(Dispatchers.IO) { PeopleSearch.search(q.trim()) }; loading = false }
    }

    ScreenFrame("بحث عن مشهور", onBack) {
        OutlinedTextField(q, { q = it }, label = { Text("اكتب اسم الشخص") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        GradientButton("ابحث", Modifier.fillMaxWidth()) { run() }
        if (loading) { Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        Spacer(Modifier.height(12.dp))

        res?.let { list ->
            if (list.isEmpty() && !loading) {
                Text("ما لقيت شخصية معروفة بهذا الاسم. جرّب الاسم بالإنجليزي أو بصيغة أدق.", color = C.amber)
                Spacer(Modifier.height(8.dp))
                GradientButton("ابحث بالنت", Modifier.fillMaxWidth()) { open("https://www.google.com/search?q=" + Uri.encode(q)) }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(list) { p ->
                    Glass(Modifier.fillMaxWidth()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            p.photo?.let {
                                AsyncImage(it, null, Modifier.size(84.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(p.name, color = C.text, fontSize = 20.sp)
                                Text(p.desc.take(160), color = C.dim, fontSize = 13.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        @OptIn(ExperimentalLayoutApi::class)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            p.links.forEach { (label, url) -> AssistChip(onClick = { open(url) }, label = { Text(label) }) }
                            AssistChip(onClick = { open("https://www.google.com/search?tbm=isch&q=" + Uri.encode(p.name)) }, label = { Text("صور") })
                        }
                    }
                }
            }
        }
    }
}
