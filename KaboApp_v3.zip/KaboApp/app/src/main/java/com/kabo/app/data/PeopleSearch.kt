package com.kabo.app.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

data class Person(val name: String, val desc: String, val photo: String?, val links: List<Pair<String, String>>)

/**
 * بحث عن شخصيات مشهورة (اللي إلها صفحة ويكيبيديا) بالاسم، مع صورتها الرسمية وروابط
 * حساباتها الموثقة من ويكيداتا (موقع رسمي، إنستغرام، إكس، يوتيوب، فيسبوك، تيك توك).
 */
object PeopleSearch {
    private val client = OkHttpClient()

    private fun get(url: String): JSONObject? = try {
        client.newCall(Request.Builder().url(url).header("User-Agent", "KaboApp/1.0").build()).execute().use {
            if (it.isSuccessful) JSONObject(it.body!!.string()) else null
        }
    } catch (e: Exception) { null }

    private class Hit(val qid: String, val title: String, val desc: String, val photo: String?, val link: String, val index: Int)

    fun search(q: String): List<Person> {
        val e = URLEncoder.encode(q, "UTF-8")
        val hits = LinkedHashMap<String, Hit>()
        for (lang in listOf("ar", "en")) {
            val j = get("https://$lang.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=$e&gsrlimit=5" +
                "&prop=pageprops|pageimages|extracts&ppprop=wikibase_item&piprop=thumbnail&pithumbsize=500" +
                "&exintro=1&explaintext=1&exsentences=2&exlimit=5&format=json") ?: continue
            val pages = j.optJSONObject("query")?.optJSONObject("pages") ?: continue
            val list = pages.keys().asSequence().map { pages.getJSONObject(it) }.sortedBy { it.optInt("index") }
            for (pg in list) {
                val qid = pg.optJSONObject("pageprops")?.optString("wikibase_item").orEmpty()
                if (qid.isBlank() || qid in hits) continue
                hits[qid] = Hit(qid, pg.optString("title"), pg.optString("extract").trim(),
                    pg.optJSONObject("thumbnail")?.optString("source"),
                    "https://$lang.wikipedia.org/?curid=${pg.optInt("pageid")}", hits.size)
            }
        }
        if (hits.isEmpty()) return emptyList()

        val ids = hits.keys.joinToString("|")
        val ent = get("https://www.wikidata.org/w/api.php?action=wbgetentities&ids=$ids&props=claims&format=json")
            ?.optJSONObject("entities") ?: return emptyList()

        fun JSONObject.claim(p: String): String? = optJSONObject("claims")?.optJSONArray(p)?.optJSONObject(0)
            ?.optJSONObject("mainsnak")?.optJSONObject("datavalue")?.opt("value") as? String

        val out = mutableListOf<Person>()
        for (h in hits.values) {
            val en = ent.optJSONObject(h.qid) ?: continue
            // بس البشر (P31 = Q5)
            val inst = en.optJSONObject("claims")?.optJSONArray("P31") ?: continue
            val human = (0 until inst.length()).any {
                (inst.getJSONObject(it).optJSONObject("mainsnak")?.optJSONObject("datavalue")?.optJSONObject("value")?.optString("id")) == "Q5"
            }
            if (!human) continue
            val links = mutableListOf("ويكيبيديا" to h.link)
            en.claim("P856")?.let { links += "الموقع الرسمي" to it }
            en.claim("P2003")?.let { links += "إنستغرام" to "https://instagram.com/$it" }
            en.claim("P2002")?.let { links += "إكس (تويتر)" to "https://x.com/$it" }
            en.claim("P2013")?.let { links += "فيسبوك" to "https://facebook.com/$it" }
            en.claim("P2397")?.let { links += "يوتيوب" to "https://youtube.com/channel/$it" }
            en.claim("P7085")?.let { links += "تيك توك" to "https://tiktok.com/@$it" }
            out += Person(h.title, h.desc, h.photo, links)
        }
        return out
    }
}
