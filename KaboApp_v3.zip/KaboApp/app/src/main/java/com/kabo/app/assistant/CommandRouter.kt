package com.kabo.app.assistant

import android.content.Context

/** يحول الكلام المفهوم إلى فعل ويرجع نص الرد. يشتغل على خيط خلفي. */
object CommandRouter {

    private val openWords = listOf("افتح", "شغل تطبيق", "افتحلي", "شغلي تطبيق")

    fun handle(ctx: Context, raw: String): String {
        val t = normalize(raw)

        greeting(t)?.let { return it }

        if (t.contains("الكشاف") || t.contains("الفلاش")) {
            val on = !(t.contains("اطفي") || t.contains("سكر") || t.contains("وقف"))
            return if (KaboAccessibilityService.torch(ctx, on)) {
                if (on) "شغلت الكشاف" else "طفيت الكشاف"
            } else "ما قدرت أتحكم بالكشاف"
        }

        if (t.contains("الرئيسية") || t.contains("شاشة البداية")) {
            return needsAccess { KaboAccessibilityService.home() }
        }
        if (t == "ارجع" || t.contains("للخلف") || t.contains("رجوع")) {
            return needsAccess { KaboAccessibilityService.back() }
        }
        if (t.contains("الاشعارات")) {
            return needsAccess { KaboAccessibilityService.notifications() }
        }
        if (t.contains("التطبيقات الاخيرة") || t.contains("التطبيقات المفتوحة")) {
            return needsAccess { KaboAccessibilityService.recents() }
        }

        for (w in openWords) {
            if (t.startsWith(w)) {
                val app = t.removePrefix(w).trim()
                if (app.isBlank()) return "أي تطبيق بدك أفتح؟"
                return if (KaboAccessibilityService.openApp(ctx, app)) "فتحت $app"
                else "ما لقيت تطبيق اسمه $app"
            }
        }

        return Answerer.answer(raw)
    }

    private fun needsAccess(action: () -> Boolean): String =
        if (!KaboAccessibilityService.isEnabled()) "فعّل صلاحية الوصول لكابو من الإعدادات أول"
        else if (action()) "تم" else "ما قدرت أنفذ"

    private fun greeting(t: String): String? = when {
        t.contains("صباح الخير") -> "صباح النور"
        t.contains("مساء الخير") -> "مساء النور"
        t.contains("السلام عليكم") -> "وعليكم السلام ورحمة الله"
        t.contains("كيف حالك") || t.contains("شلونك") -> "تمام الحمد لله، أنت كيفك؟"
        else -> null
    }

    /** تبسيط النص العربي لتسهيل المطابقة. */
    fun normalize(s: String) = s.trim()
        .replace(Regex("[ً-ْ]"), "")
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        .replace("ى", "ي")
        .lowercase()
}
