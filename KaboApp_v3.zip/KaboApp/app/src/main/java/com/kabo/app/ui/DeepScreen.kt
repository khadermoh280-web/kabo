package com.kabo.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.AiCfg
import com.kabo.app.data.DeepResult
import com.kabo.app.data.DeepSearch
import kotlinx.coroutines.launch

@Composable
fun DeepScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved = remember { DeepSearch.cfg(ctx) }
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<DeepResult?>(null) }
    var base by remember { mutableStateOf(saved.base) }
    var model by remember { mutableStateOf(saved.model) }
    var key by remember { mutableStateOf(saved.key) }
    var showCfg by remember { mutableStateOf(saved.key.isBlank()) }

    fun open(url: String) { Gate.suppress = true; ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    ScreenFrame("بحث عميق", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            OutlinedTextField(q, { q = it }, label = { Text("شو بدك تعرف؟ (شخص، موضوع، سؤال)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            GradientButton("ابحث بعمق", Modifier.fillMaxWidth()) {
                if (q.isBlank() || status != null) return@GradientButton
                err = ""; res = null; status = "بدأت..."
                scope.launch {
                    try { res = DeepSearch.run(ctx, q.trim()) { status = it } }
                    catch (e: Throwable) { err = e.message ?: "خطأ غير معروف" }
                    status = null
                }
            }
            status?.let { Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, color = C.dim, fontSize = 13.sp) }
            if (err.isNotBlank()) Text(err, color = C.amber, modifier = Modifier.padding(top = 8.dp))

            res?.let { r ->
                Spacer(Modifier.height(14.dp))
                Glass(Modifier.fillMaxWidth()) { SelectionContainer { Text(r.answer, color = C.text, fontSize = 15.sp) } }
                Spacer(Modifier.height(12.dp))
                Text("المصادر", color = C.text, fontSize = 18.sp)
                r.sources.forEachIndexed { i, s ->
                    TextButton(onClick = { open(s.url) }) { Text("[${i + 1}] ${s.title.take(60)}", color = C.cyan) }
                }
            }

            Spacer(Modifier.height(16.dp))
            TextButton(onClick = { showCfg = !showCfg }) { Text(if (showCfg) "إخفاء إعدادات الذكاء الاصطناعي" else "إعدادات الذكاء الاصطناعي", color = C.dim) }
            if (showCfg) Glass(Modifier.fillMaxWidth()) {
                Text("أي خدمة متوافقة مع OpenAI. الافتراضي Hugging Face بنموذج Qwen المفتوح (بدك توكن مجاني من huggingface.co/settings/tokens). للخصوصية الكاملة شغّل Ollama على جهازك وحط عنوانه هنا.", color = C.dim, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(base, { base = it }, label = { Text("العنوان (Base URL)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model, { model = it }, label = { Text("اسم النموذج") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(key, { key = it }, label = { Text("التوكن / API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                GradientButton("حفظ", Modifier.fillMaxWidth()) { DeepSearch.save(ctx, AiCfg(base, model, key)); showCfg = false }
            }
        }
    }
}
